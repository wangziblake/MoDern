# ***************************************************************************************** #
# This is the project folder for XCloud-MoDern, including the demonstration data and scripts.
#
# More details about the paper could be found by:
# Zi Wang et al.
# XCloud-MoDern: An Artificial Intelligence Cloud for Accelerated NMR Spectroscopy,
# arXiv preprint, arXiv:2012.14830, 2020.
# https://arxiv.org/abs/2012.14830
#
# Email: Xiaobo Qu (quxiaobo@xmu.edu.cn) CC: Zi Wang (wangzi1023@stu.xmu.edu.com)
# Homepage: http://csrc.xmu.edu.cn
# 
# Affiliations: Computational Sensing Group (CSG), Departments of Electronic Science, Xiamen University, Xiamen 361005, China
# All rights are reserved by CSG.
#
# The project files are arranged by Zi Wang.
# Latest update: Feb. 12, 2021.
# 
#
# Acknowledgements:
# The authors thank NMRPipe and MddNMR for sharing 2D and 3D NMR data on the websites; NMRPipe and SPARKY for data processing support.
#
#
# Note:
# the 2D source data is publicly available from the NMRPipe website: https://www.ibbr.umd.edu/nmrpipe/index.html;
# the 3D source data is publicly available from the MddNMR website: http://mddnmr.spektrino.com/.
# If you use the data, please cite the paper following their requirement.
# We only provide the demo NUS data, NUS mask, and the corresponding processing scripts on the cloud.
#
# ***************************************************************************************** #

Below are details about what are included under the root folder 'Demo_data_scripts_XCloud-MoDern'.

|-- 2D_HSQC_Gb1	# 2D demo NUS data and scripts 
|   |-- NUS Data for quick try	# NUS data and the corresponding NUS mask (NUS density=25%)
|   `-- Scripts	# Scripts for 2D demo data
`-- 3D_HNCO_Azurin	# 3D demo NUS data and scripts 
|   |-- NUS Data for quick try	# NUS data and the corresponding NUS mask (NUS density=20%)
|   `-- Scripts	# Scripts for 3D demo data

# ---------------------------------- The end of the file --------------------------------#
